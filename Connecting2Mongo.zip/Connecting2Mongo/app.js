const express = require('express');
const engines = require('consolidate');
const app = express();

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));

var publicDir = require('path').join(__dirname, '/public');
app.use(express.static(publicDir));

//npm i handlebars consolidate --save
app.engine('hbs', engines.handlebars);
app.set('staff', './views');
app.set('view engine', 'hbs');

app.get('/addTraineeAccout', (req, res) => {
    res.render('addTraineeAccout');
})

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://datnq18017:dat123nguyen123@cluster0.yg8a8.mongodb.net/test";

app.post('/doInsert', async(req, res) => {
    let inputName = req.body.txtName;
    let inputWeight = req.body.txtWeight;
    let newToy = { name: inputName, weigh: inputWeight };

    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    await dbo.collection("course").insertOne(newToy);
    res.redirect('listOfAccount'); //
})

//localhost:3000
app.get('/', async function(req, res) {
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    let result = await dbo.collection("course").find({}).toArray();
    res.render('index', { model: result });
})

app.get('/remove', async(req, res) => {
    let id = req.query.id;
    var ObjectID = require('mongodb').ObjectID;
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    await dbo.collection("Toy").deleteOne({ _id: ObjectID(id) });
    res.redirect('/');

})

app.get('/listOfAccount', async(req, res) => {
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    let result = await dbo.collection("course").find({}).toArray();
    res.render('listOfAccount', { model: result });
})

app.get('/register', (req, res) => {
    res.render('register');
})

app.get('/allUser', async function(req, res) {
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    let result = await dbo.collection("User").find({}).toArray();
    res.render('allUser', { model: result });
})

app.post("/doRegister", async(req, res) => {
    let inputName = req.body.txtName;
    let inputEmail = req.body.txtEmail;
    if (inputName.length < 2) {
        let errorModel = {
            nameError: "Invalid"
        };
        res.redirect("/register");
    } else {
        let data = inputName + ";" + inputEmail + "\n";
        fs.appendFile(fileName, data, function(err) {
            res.redirect("/allUser");
        });
        let client = await MongoClient.connect(url);
        let dbo = client.db("ToyDB");
        await dbo
            .collection("User")
            .insertOne({ name: inputName, email: inputEmail });
        res.redirect("/allUser");
    }
});

app.post('/doaddCourse', async(req, res) => {
    let inputName = req.body.txtName;
    let inputTime = req.body.txtTime;
    let inputDescription = req.body.txtDescription;
    let newToy = { name: inputName, Time: inputTime, Description: inputDescription };

    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    await dbo.collection("course").insertOne(newToy);
    res.redirect('addCourse'); //
})

app.get('/addCourse', async(req, res) => {
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    let result = await dbo.collection("category").find({}).toArray();
    res.render('addCourse', { model: result });
})

app.get('/removecourse', async(req, res) => {
    let id = req.query.id;
    var ObjectID = require('mongodb').ObjectID;
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    await dbo.collection("course").deleteOne({ _id: ObjectID(id) });
    res.redirect('addCourse');

})

app.get('/courseCategory', async(_req, res) => {
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    let result = await dbo.collection("category").find({}).toArray();
    res.render('courseCategory', { model: result });
})

app.get('/removecategory', async(req, res) => {
    let id = req.query.id;
    var ObjectID = require('mongodb').ObjectID;
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    await dbo.collection("category").deleteOne({ _id: ObjectID(id) });
    res.redirect('courseCategory');
});

app.post('/doaddCategory', async(req, res) => {
    let inputName = req.body.txtName;
    let inputDescription = req.body.txtDescription;
    let newCategory = { name: inputName, description: inputDescription };

    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    await dbo.collection("category").insertOne(newCategory);
    res.redirect('courseCategory'); //
})

app.get('/addCategory', async(req, res) => {
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    let result = await dbo.collection("category").find({}).toArray();
    res.render('addCategory', { model: result });
})

app.get('/addCourseIFM', async(req, res) => {
    let inputName = req.body.txtName;
    let inputDescription = req.body.txtDescription;
    let newCategory = { name: inputName, description: inputDescription };

    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    await dbo.collection("course").insertOne(newCategory);
    res.redirect('viewCourse'); //
})

app.get('/viewCourse', async(req, res) => {
    let client = await MongoClient.connect(url);
    let dbo = client.db("ToyDB");
    let result = await dbo.collection("course").find({}).toArray();
    res.render('viewCourse', { model: result });
})

const PORT = process.env.PORT || 3000;
app.listen(PORT);